  prototype.addListeners = function () {
    var options = this.options,
        $this = this.$element,
        $cropper = this.$cropper;

    if ($.isFunction(options.dragstart)) {
      $this.on(EVENT_DRAG_START, options.dragstart);
    }

    if ($.isFunction(options.dragmove)) {
      $this.on(EVENT_DRAG_MOVE, options.dragmove);
    }

    if ($.isFunction(options.dragend)) {
      $this.on(EVENT_DRAG_END, options.dragend);
    }

    if ($.isFunction(options.zoomin)) {
      $this.on(EVENT_ZOOM_IN, options.zoomin);
    }

    if ($.isFunction(options.zoomout)) {
      $this.on(EVENT_ZOOM_OUT, options.zoomout);
    }

    if ($.isFunction(options.change)) {
      $this.on(EVENT_CHANGE, options.change);
    }

    $cropper.on(EVENT_MOUSE_DOWN, $.proxy(this.dragstart, this));

    if (options.zoomable && options.mouseWheelZoom) {
      $cropper.on(EVENT_WHEEL, $.proxy(this.wheel, this));
    }

    if (options.doubleClickToggle) {
      $cropper.on(EVENT_DBLCLICK, $.proxy(this.dblclick, this));
    }

    $document.on(EVENT_MOUSE_MOVE, (this._dragmove = proxy(this.dragmove, this))).on(EVENT_MOUSE_UP, (this._dragend = proxy(this.dragend, this)));

    if (options.responsive) {
      $window.on(EVENT_RESIZE, (this._resize = proxy(this.resize, this)));
    }
  };

  prototype.removeListeners = function () {
    var options = this.options,
        $this = this.$element,
        $cropper = this.$cropper;

    if ($.isFunction(options.dragstart)) {
      $this.off(EVENT_DRAG_START, options.dragstart);
    }

    if ($.isFunction(options.dragmove)) {
      $this.off(EVENT_DRAG_MOVE, options.dragmove);
    }

    if ($.isFunction(options.dragend)) {
      $this.off(EVENT_DRAG_END, options.dragend);
    }

    if ($.isFunction(options.zoomin)) {
      $this.off(EVENT_ZOOM_IN, options.zoomin);
    }

    if ($.isFunction(options.zoomout)) {
      $this.off(EVENT_ZOOM_OUT, options.zoomout);
    }

    if ($.isFunction(options.change)) {
      $this.off(EVENT_CHANGE, options.change);
    }

    $cropper.off(EVENT_MOUSE_DOWN, this.dragstart);

    if (options.zoomable && options.mouseWheelZoom) {
      $cropper.off(EVENT_WHEEL, this.wheel);
    }

    if (options.doubleClickToggle) {
      $cropper.off(EVENT_DBLCLICK, this.dblclick);
    }

    $document.off(EVENT_MOUSE_MOVE, this._dragmove).off(EVENT_MOUSE_UP, this._dragend);

    if (options.responsive) {
      $window.off(EVENT_RESIZE, this._resize);
    }
  };
