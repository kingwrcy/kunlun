  $.extend(Cropper.prototype, prototype);
